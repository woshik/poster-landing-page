<template>
  <Home />
</template>

<script>
import Home from "./screen/Home";

export default {
  name: "App",
  components: {
    Home,
  },
};
</script>