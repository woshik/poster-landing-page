<template>
  <section class="service-section">
    <div class="container marketing">
      <div class="row text-center">
        <div class="col-lg-3">
          <p>
            <font-awesome-icon icon="gift" />
          </p>
          <h2 class="service-title">Außergewöhnlich</h2>
          <p class="service-subtitle">Beschenke deine Liebsten mit magischen Momenten.</p>
        </div>

        <div class="col-lg-3">
          <p>
             <font-awesome-icon icon="vote-yea" />
          </p>
          <h2 class="service-title">Hochwertiger Druck</h2>
          <p class="service-subtitle">Fineart-Druck und hochwertige Qualität.</p>
        </div>

        <div class="col-lg-3">
          <p>
             <font-awesome-icon icon="shipping-fast" />
          </p>
          <h2 class="service-title">Schnelle Lieferung</h2>
          <p class="service-subtitle">Sehr schnelle Lieferung innerhalb Deutschlands.</p>
        </div>

        <div class="col-lg-3">
          <p>
             <font-awesome-icon icon="lock" />
          </p>
          <h2 class="service-title">Sichere Zahlung</h2>
          <p class="service-subtitle">Paypal/ Lastschrift/ Sofort/ Visa/ Mastercard</p>
        </div>
      </div>
      <!-- /.row -->
    </div>
  </section>
</template>

<script>
export default {
  name: "Service",
};
</script>
