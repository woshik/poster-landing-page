<template>
  <section class="full-banner">
    <div class="container">
      <div class="banner-height">
        <div class="row featurette">
          <div class="col-md-6">
            <h2 class="featurette-heading">
              <span class="text-muted"></span>
            </h2>
            <div class="heading-title">Das perfekte personalisierte Geschenk</div>
            <div class="heading-title-default">Das Sternenhimmel Poster</div>
            <ul class="features">
              <li>Mit Wunsch-Datum und Wunsch-Ort</li>
              <li>Text und Farbe personalisierbar</li>
              <li>Hochwertig und außergewöhnlich</li>
            </ul>
            <div class="features-details">
              Gestalte dein persönliches Sternenhimmel Poster für dich, um besondere Momente einzufangen oder als
              Geschenk
              für deine Liebsten.
            </div>
            <button
              class="btn btn-outline-primary btn-features mt-3"
            >Jetzt gestalten und Freude bereiten!</button>
          </div>
        </div>
      </div>
    </div>
  </section>
</template>

<script>
export default {
  name: "FullBanner",
};
</script>