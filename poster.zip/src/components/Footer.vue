<template>
  <footer class="page-footer">
    <div class="container-fluid footer-upper-container">
      <div class="row text-center">
        <div class="col-12">
          <ul class="list-horizontal">
            <li>
              <a href="#!">Home</a>
            </li>
            <li>
              <a href="#!">Impressum</a>
            </li>
            <li>
              <a href="#!">AGB</a>
            </li>
            <li>
              <a href="#!">Datenschutz</a>
            </li>
            <li>
              <a href="#!">Versand- und Zahlungsinformationen</a>
            </li>
            <li>
              <a href="#!">Widerruf</a>
            </li>
          </ul>
        </div>
        <div class="col-md-6 mx-auto">
          <div class="footer-copyright">
            © 2020 Sternenhimmel Poster by Momentgold - Powered by Shopify
            Alle Preise inkl. MwSt. und zzgl. Versandkosten
          </div>
        </div>
      </div>
    </div>
    <div class="container-fluid container-footer-lower">
      <div class="row text-center">
        <div class="col-md-12">
          <div class="payment-title">Sichere Zahlung mit</div>
        </div>
        <div class="col-md-12 mt-3">
          <img src="../assets/images/payment.png" alt />
        </div>
      </div>
    </div>
  </footer>
</template>

<script>
export default {
  name: "Footer",
};
</script>